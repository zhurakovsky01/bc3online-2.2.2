#!/usr/bin/env bash

cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" || exit 1
. h-manifest.conf

[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo "No $CUSTOM_CONFIG_FILENAME, run h-config.sh first" && exit 1

mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
log="${CUSTOM_LOG_BASENAME}.log"
# keep one previous log, start a fresh one so it never grows without limit
[[ -f $log ]] && mv -f "$log" "${log}.1"

chmod +x ./bc3-miner
./bc3-miner $(< "$CUSTOM_CONFIG_FILENAME") 2>&1 | tee "$log"
