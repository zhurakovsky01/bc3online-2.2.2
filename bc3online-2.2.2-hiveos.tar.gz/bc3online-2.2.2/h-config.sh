#!/usr/bin/env bash
# Builds miner.conf from the flight sheet.
#   Wallet and worker template -> --user  (use %WAL%.%WORKER_NAME%)
#   Pool URL                   -> --pool  (bc3.online:3111 = PPLNS, bc3.online:3112 = SOLO)
#   Extra config arguments     -> appended as is (e.g. --mode solo, --intensity 90)

[[ -z $CUSTOM_NAME ]] && . "$(dirname "${BASH_SOURCE[0]}")/h-manifest.conf"

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE (wallet.worker) is empty${NOCOLOR}" && return 1

conf="--user $CUSTOM_TEMPLATE --backend cuda --require-gpu --stats-interval 10"

if [[ -n $CUSTOM_URL ]]; then
	pool=$(head -n 1 <<< "$CUSTOM_URL")
	pool=${pool#stratum+tcp://}
	pool=${pool#stratum://}
	pool=${pool#tcp://}
	pool=${pool%/}
	# --pool overrides --mode, so only pass it when the extra config does not pick a mode
	[[ $CUSTOM_USER_CONFIG != *--mode* ]] && conf+=" --pool $pool"
fi

[[ -n $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf" > "$CUSTOM_CONFIG_FILENAME"
echo "miner.conf: $conf"
