#!/usr/bin/env bash
# Sourced by the HiveOS agent: must set $khs (total kH/s) and $stats (JSON).
# The miner prints only a total hashrate, so per-card values are the total split evenly.

_bc3_dir=/hive/miners/custom/${CUSTOM_MINER:-bc3online-2.2.2}
[[ -f $_bc3_dir/h-manifest.conf ]] || _bc3_dir=$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")
. "$_bc3_dir/h-manifest.conf"

_bc3_log="${CUSTOM_LOG_BASENAME}.log"
khs=0
stats=null

_bc3_line=""
if [[ -f $_bc3_log ]] && (( $(date +%s) - $(stat -c %Y "$_bc3_log") < 90 )); then
	_bc3_line=$(tail -n 300 "$_bc3_log" | grep -a '^\[miner\]' | tail -n 1)
fi

if [[ -n $_bc3_line ]]; then
	# "[miner] 2.61 MH/s | shares 12 ok (0.4/min), 0 stale, 1 rejected | ..."
	read -r _bc3_val _bc3_unit < <(sed -nE 's/^\[miner\] +([0-9.]+) *([kKMGT]?)H\/s.*/\1 \2/p' <<< "$_bc3_line")
	case $_bc3_unit in
		"")  _bc3_mul=0.001 ;;
		k|K) _bc3_mul=1 ;;
		M)   _bc3_mul=1000 ;;
		G)   _bc3_mul=1000000 ;;
		T)   _bc3_mul=1000000000 ;;
	esac
	khs=$(awk -v v="${_bc3_val:-0}" -v m="${_bc3_mul:-0}" 'BEGIN{printf "%.3f", v*m}')

	_bc3_acc=$(sed -nE 's/.*shares ([0-9]+) ok.*/\1/p' <<< "$_bc3_line")
	_bc3_rej=$(sed -nE 's/.* ([0-9]+) rejected.*/\1/p' <<< "$_bc3_line")

	_bc3_gpu_json=/run/hive/gpu-stats.json
	[[ -f $_bc3_gpu_json ]] && _bc3_gs=$(< "$_bc3_gpu_json") || _bc3_gs='{}'

	_bc3_uptime=$(ps -o etimes= -C bc3-miner 2>/dev/null | sort -n | tail -n 1 | tr -d ' ')

	stats=$(jq -c -n \
		--argjson gs "$_bc3_gs" \
		--argjson khs "$khs" \
		--argjson acc "${_bc3_acc:-0}" \
		--argjson rej "${_bc3_rej:-0}" \
		--argjson up "${_bc3_uptime:-0}" \
		--arg ver "$CUSTOM_VERSION" \
		--arg algo "$CUSTOM_ALGO" '
		def hex2dec: ascii_downcase | explode
			| map(if . >= 97 then . - 87 else . - 48 end)
			| reduce .[] as $d (0; . * 16 + $d);
		($gs.brand // []) as $b
		| [range(0; $b|length) | select($b[.] == "nvidia")] as $idx
		| ($idx|length) as $n
		| {
			hs: (if $n > 0 then [$idx[] | ($khs / $n)] else [$khs] end),
			hs_units: "khs",
			temp: [$idx[] | ($gs.temp[.] // 0)],
			fan: [$idx[] | ($gs.fan[.] // 0)],
			bus_numbers: [$idx[] | (($gs.busids[.] // "00") | split(":")[0] | hex2dec)],
			uptime: $up,
			ar: [$acc, $rej],
			algo: $algo,
			ver: $ver
		}')
	[[ -z $stats ]] && stats=null
fi
